import pandas as pd
import numpy as np
import operator
from collections import Counter
import matplotlib.pyplot as plt

"""
Input file names:

mnist_train.csv
mnist_test.csv

"""
class KNN(object):
    def __init__(self):
		# Call the loading functions and load data to the related variables.
		pass

    def load_train_data(self):
		# Return the variable of Train data that may you need.
		pass

    def load_test_data(self):
		# Return the variable of Test data that may you need.
		pass

    def get_distance_matrix_of_test_to_train(self, k=9):
		pass

    def predict_test_data(self, k=9):
		pass

    def plot_learning_curve(self, plot_curve1_dict):
		# Plot your results and save it as a picture.
		pass

    def run(self):
		# Run your algorithm for different Ks.
		pass


if __name__ == "__main__":
    obj = KNN()
    obj.run()